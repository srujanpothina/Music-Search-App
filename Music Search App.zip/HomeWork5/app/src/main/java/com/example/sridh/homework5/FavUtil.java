package com.example.sridh.homework5;

import android.app.Activity;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class FavUtil {
    static public class FavJSONParser {
        static ArrayList<Favorites> parseFav(String is, Activity context) throws JSONException {
            ArrayList<Favorites> FavoritesList = new ArrayList<Favorites>();
            if(context instanceof MainActivity){
                JSONObject root = new JSONObject(is);
                JSONObject results = root.getJSONObject("results");
                JSONObject trackmatches = results.getJSONObject("trackmatches");
                JSONArray q = trackmatches.getJSONArray("track");
                for(int i =0;i<q.length();i++){
                    JSONObject jsonObject = q.getJSONObject(i);
                    Favorites favorites = new Favorites();
                    favorites.setName(jsonObject.getString("name"));
                    favorites.setArtist(jsonObject.getString("artist"));
                    favorites.setUrl(jsonObject.getString("url"));
                    JSONArray choice = jsonObject.getJSONArray("image");
                    ArrayList<String> bh = new ArrayList<String>();
                    for(int j =0;j<choice.length();j++){
                        JSONObject image = choice.getJSONObject(j);
                        String url = image.getString("#text");
                        String size = image.getString("size");
                        if(size.trim().equals("small")){
                            favorites.setImage_URL_small(url);
                        } else if(size.trim().equals("large")){
                            favorites.setImage_URL_large(url);
                        }
                    }
                    favorites.setStar(false);
                    ArrayList<Favorites> starred = new ArrayList<Favorites>();
                    starred.addAll(MainActivity.getStarred());
                    for (int x = 0;x<starred.size();x++){
                        if(starred.get(x).toString().equals(favorites.toString())){
                            favorites.setStar(true);
                            x = starred.size() + 1;
                        }
                    }
                    FavoritesList.add(favorites);
                }
            } else {
                JSONObject root = new JSONObject(is);
                JSONObject results = root.getJSONObject("similartracks");
                JSONArray q = results.getJSONArray("track");
                for(int i =0;i<q.length();i++){
                    JSONObject jsonObject = q.getJSONObject(i);
                    Favorites favorites = new Favorites();
                    favorites.setName(jsonObject.getString("name"));
                    favorites.setUrl(jsonObject.getString("url"));
                    JSONObject artist = jsonObject.getJSONObject("artist");
                    favorites.setArtist(artist.getString("name"));
                    JSONArray choice = jsonObject.getJSONArray("image");
                    ArrayList<String> bh = new ArrayList<String>();
                    for(int j =0;j<choice.length();j++){
                        JSONObject image = choice.getJSONObject(j);
                        String url = image.getString("#text");
                        String size = image.getString("size");
                        if(size.trim().equals("small")){
                            favorites.setImage_URL_small(url);
                        } else if(size.trim().equals("large")){
                            favorites.setImage_URL_large(url);
                        }
                    }
                    favorites.setStar(false);
                    ArrayList<Favorites> starred = new ArrayList<Favorites>();
                    starred.addAll(MainActivity.getStarred());
                    for (int x = 0;x<starred.size();x++){
                        if(starred.get(x).toString().equals(favorites.toString())){
                            favorites.setStar(true);
                            x = starred.size() + 1;
                        }
                    }
                    FavoritesList.add(favorites);
                }
            }
            return FavoritesList;
        }
    }
}

