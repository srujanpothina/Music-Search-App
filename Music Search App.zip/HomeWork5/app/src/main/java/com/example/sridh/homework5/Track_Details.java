package com.example.sridh.homework5;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.JsonToken;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.stream.JsonWriter;
import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Track_Details extends AppCompatActivity {
    Favorites favorites = new Favorites();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track__details);
        Toolbar actions = (Toolbar) findViewById(R.id.app_bar);
        actions.setTitle("Track Details");
        setSupportActionBar(actions);
        if(getIntent().getExtras()!=null)
        {
            favorites = (Favorites) getIntent().getSerializableExtra("fav");
        }
        String tx = new String();
        //tx = favorites.getName().trim().replaceAll("\\(.*?\\) ?", "");
        String art = new String();
        //art = favorites.getArtist().trim().replaceAll("\\(.*?\\) ?", "");
        String encode = " ";
        try {
            tx = URLEncoder.encode(favorites.getName().trim(),"UTF-8");
            if(!(favorites.getArtist().trim().isEmpty())){
                art = URLEncoder.encode(favorites.getArtist().trim(),"UTF-8");
                encode = "&artist=" + art;

            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        String u = new String("http://ws.audioscrobbler.com/2.0/?method=track.getsimilar"+encode.trim()+"&track="+tx.trim()+"&api_key=ef92cdbddee6dba109365b0a5c5d4206&format=json&limit=10");
        getdata(u);
        loadData(favorites);
    }
    public void getdata(String u){
        new GetData(Track_Details.this).execute(u);
    }
    public void loadData(Favorites fav){
        ImageView image = (ImageView) findViewById(R.id.image_large);
        TextView name = (TextView) findViewById(R.id.name);
        TextView artist = (TextView) findViewById(R.id.artist);
        final TextView url = (TextView) findViewById(R.id.url);
        name.setText(fav.getName());
        artist.setText(fav.getArtist());
        url.setText(fav.getUrl());
        if(!(favorites.getImage_URL_small().trim().isEmpty())){
            Picasso.with(Track_Details.this).load(fav.getImage_URL_large()).into(image);
        }
        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!(url.getText().toString().trim().isEmpty())){
                    Intent intent= new Intent();
                    intent=new Intent(Intent.ACTION_VIEW, Uri.parse(url.getText().toString()));
                    startActivity(intent);
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getTitle().toString().trim().equals("Home")){
            ListView listView = (ListView) findViewById(R.id.listview3);
            listView.setAdapter(null);
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("HOME", true);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } else if(item.getTitle().toString().trim().equals("Quit")){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
