package com.example.sridh.homework5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class SearchResult extends AppCompatActivity {
    ArrayList<Favorites> favorites = new ArrayList<Favorites>();
    public int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_result);
        Toolbar actions = (Toolbar) findViewById(R.id.app_bar);
        actions.setTitle("Search Results");
        setSupportActionBar(actions);
        if(getIntent().getExtras()!=null)
        {
            favorites = (ArrayList<Favorites>) getIntent().getSerializableExtra("favorites");
        }

        ListView listView = (ListView) findViewById(R.id.listview2);
        Track_List track_list = new Track_List(SearchResult.this,R.layout.list_view,favorites);
        listView.setAdapter(track_list);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getTitle().toString().trim().equals("Home")){
            ListView listView = (ListView) findViewById(R.id.listview2);
            listView.setAdapter(null);
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("HOME", true);
            startActivity(intent);
        } else if(item.getTitle().toString().trim().equals("Quit")){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
    public void callIntent(Favorites favi){
        Intent intent = new Intent(SearchResult.this,Track_Details.class);
        intent.putExtra("fav",favi);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
