package com.example.sridh.homework5;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Space;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public final static String MY_PREFS_NAME = "LIKE";
    public int list_position;
    public static ArrayList<Favorites> list = new ArrayList<Favorites>();
    public static ArrayList<Favorites> starred = new ArrayList<Favorites>();
    public static int hash_value;
    EditText music_search;
    static Context con = getContext();
    HashMap<Integer,Favorites> h = null;
    public static Context getContext() {
        return con;
    }
    public static ArrayList<Favorites> getList() {
        return list;
    }
    public static int sizeStarred(){
        if(!(starred.equals(null))){
            return starred.size();
        } else {
            return 0;
        }
    }

    public static ArrayList<Favorites> getStarred() {
        return starred;
    }

    public static void setStarred(ArrayList<Favorites> starred) {
        MainActivity.starred = starred;
    }

    public static void removeStarred(Favorites fav, Activity context) {
        if(!(starred.equals(null))){
            int pos = starred.size();
            for(int x =0;x<pos;x++){
                if(starred.get(x).toString().trim().equals(fav.toString().trim()) ){
                    starred.remove(x);
                    //break;
                    x = starred.size() + 1;
                }
            }
            SharedPreferences mPrefs = context.getApplicationContext().getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
            SharedPreferences.Editor editor = mPrefs.edit();
            Gson gson = new Gson();
            String json = gson.toJson(starred);
            editor.putString("STARR", json);
            editor.commit();
        }
    }

    public static void addStarred(Favorites fav, Activity context) {
        starred.add(fav);
        SharedPreferences mPrefs = context.getApplicationContext().getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = mPrefs.edit();
        Gson gson = new Gson();
        String json = gson.toJson(starred);
        editor.putString("STARR", json);
        editor.commit();
    }

    public static void setList(ArrayList<Favorites> list) {
        MainActivity.list = list;
    }
    public void callIntent(ArrayList<Favorites> favorites){
        Intent intent = new Intent(MainActivity.this,SearchResult.class);
        intent.putExtra("favorites",favorites);
        startActivity(intent);
    }

    public void callIntentTrack(Favorites favorites){
        Intent intent = new Intent(MainActivity.this,Track_Details.class);
        intent.putExtra("fav",favorites);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(getIntent().getBooleanExtra("EXIT", false)){
            finish();
        } else {
            list.clear();
            starred.clear();
            SharedPreferences mPrefs = getApplicationContext().getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
//            SharedPreferences.Editor ed = mPrefs.edit();
//            ed.clear();
//            ed.commit();
            Gson gson = new Gson();
            String restoredText = mPrefs.getString("STARR","");
            if(!(restoredText.trim().isEmpty())){
                Type type = new TypeToken<ArrayList<Favorites>>(){}.getType();
                starred = gson.fromJson(restoredText,type);
            }
        }
        Toolbar actions = (Toolbar) findViewById(R.id.app_bar);
        actions.setTitle("Music Search");
        setSupportActionBar(actions);
        listView(starred);
        Button search = (Button) findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isConnected()){
                    music_search = (EditText) findViewById(R.id.music_search);
                    if(music_search.getText().toString().trim().isEmpty()){
                        Toast.makeText(getBaseContext(),"Search string is empty",Toast.LENGTH_LONG).show();
                    } else {
                        String tx = new String();
                        tx = music_search.getText().toString().trim().replaceAll("\\(.*?\\) ?", "");
                        String link = new String(tx.trim().replaceAll(" ","+"));
                        
                        String encode = " ";
                        try {
                            encode = URLEncoder.encode(tx.trim(),"UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        new GetData(MainActivity.this).execute("http://ws.audioscrobbler.com/2.0/?method=track.search&track="+encode+"&api_key=ef92cdbddee6dba109365b0a5c5d4206&format=json&limit=20");
                    }
                } else {
                    Toast.makeText(getBaseContext(),"Network is not connected",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public Boolean isConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nf = cm.getActiveNetworkInfo();
        if(nf != null && nf.isConnected()){
            return true;
        } else {
            return false;
        }
    }

    public void listView(ArrayList<Favorites> fav){
        ListView listView = (ListView) findViewById(R.id.listview1);
        Track_List track_list = new Track_List(this,R.layout.list_view,fav);
        track_list.setNotifyOnChange(true);
        track_list.notifyDataSetChanged();
        listView.setAdapter(track_list);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getTitle().toString().trim().equals("Home")){
            Toast.makeText(getBaseContext(),"In Home",Toast.LENGTH_LONG).show();
        } else if(item.getTitle().toString().trim().equals("Quit")){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.action_bar,menu);
        return super.onCreateOptionsMenu(menu);
    }
}

