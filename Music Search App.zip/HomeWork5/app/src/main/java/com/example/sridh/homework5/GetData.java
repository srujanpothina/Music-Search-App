package com.example.sridh.homework5;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class GetData extends AsyncTask<String,Void,ArrayList<Favorites>> {
    Activity context;
    Context con;
    MainActivity activity;
    Track_Details track_details;

    public GetData(Activity context) {
        this.context = context;
        this.con = context;
        if (context instanceof MainActivity){
            activity = (MainActivity) context;
        } else {
            track_details = (Track_Details) context;
        }

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(ArrayList<Favorites> favorites) {
        super.onPostExecute(favorites);
        if(favorites != null){
            if (favorites.size() > 0){
                if(context instanceof MainActivity) {
                    MainActivity.setList(favorites);
                    activity.callIntent(favorites);
                } else {
                    ListView listView = (ListView) track_details.findViewById(R.id.listview3);
                    Track_List track_list = new Track_List(track_details,R.layout.list_view,favorites);
                    listView.setAdapter(track_list);
                }
            } else {
                if (context instanceof MainActivity){
                    Toast.makeText(context.getBaseContext(),"Search result for the entered keyword is empty",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(context.getBaseContext(),"Similar tracks is empty",Toast.LENGTH_LONG).show();
                    ListView listView = (ListView) track_details.findViewById(R.id.listview3);
                    listView.setAdapter(null);
                }
            }
        } else {
            if (context instanceof MainActivity){
                Toast.makeText(context.getBaseContext(),"Search result for the entered keyword is empty",Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(context.getBaseContext(),"Similar tracks is empty",Toast.LENGTH_LONG).show();
                ListView listView = (ListView) track_details.findViewById(R.id.listview3);
                listView.setAdapter(null);
            }
        }
    }

    @Override
    protected ArrayList<Favorites> doInBackground(String... strings) {
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            int status = con.getResponseCode();
            if(status == HttpURLConnection.HTTP_OK){
                BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = reader.readLine();

                while (line != null){
                    sb.append(line);
                    line = reader.readLine();
                }
                return FavUtil.FavJSONParser.parseFav(sb.toString(),context);
            }
            else {
                Toast.makeText(context,"Error in loading list", Toast.LENGTH_LONG).show();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
