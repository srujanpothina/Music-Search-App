package com.example.sridh.homework5;

import android.app.Activity;
import android.content.Context;
import android.provider.ContactsContract;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Track_List extends ArrayAdapter<Favorites> {
    ArrayList<Favorites> list;
    SearchResult sContext;
    Track_Details track_details;
    MainActivity mContext;
    Activity context;
    int oResourse;
    ImageButton fav;


    public Track_List(@NonNull Activity context, @LayoutRes int resource, @NonNull ArrayList<Favorites> objects) {
        super(context, resource, objects);
        this.list = objects;
        this.context = context;
        if(context instanceof MainActivity){
            this.mContext = (MainActivity) context;
        } else if(context instanceof SearchResult){
            this.sContext = (SearchResult) context;
        } else {
            this.track_details = (Track_Details) context;
        }
        this.oResourse = resource;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        final int pos = position;
        if(convertView == null){
            if(context instanceof MainActivity){
                LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(oResourse,parent,false);
            } else if(context instanceof SearchResult){
                LayoutInflater inflater = (LayoutInflater) sContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(oResourse,parent,false);
            } else {
                LayoutInflater inflater = (LayoutInflater) track_details.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView = inflater.inflate(oResourse,parent,false);
            }
        }
        if(list.size()>0){
            Favorites favorites = list.get(position);
            final ImageView list_image = (ImageView) convertView.findViewById(R.id.default_image);
            if(!(favorites.getImage_URL_small().trim().isEmpty())){
                Picasso.with(context).load(favorites.getImage_URL_small()).into(list_image);
            }

            TextView album_name = (TextView) convertView.findViewById(R.id.music_name);
            album_name.setText(favorites.getName());

            TextView album_artist = (TextView) convertView.findViewById(R.id.music_artist);
            album_artist.setText(favorites.getArtist());

            fav = (ImageButton) convertView.findViewById(R.id.favrouties);
            if(favorites.getStar()){
                fav.setTag(position);
                fav.setImageResource(android.R.drawable.btn_star_big_on);
            } else {
                fav.setImageResource(android.R.drawable.btn_star_big_off);
            }
            final View finalConvertView = convertView;
            fav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                        if(list.get(pos).getStar()){
                            ImageButton favi = (ImageButton) finalConvertView.findViewById(R.id.favrouties);
                            favi.setImageResource(android.R.drawable.btn_star_big_off);
                            list.get(pos).setStar(false);
                            Favorites favorites = list.get(pos);
                            MainActivity.removeStarred(favorites,context);
                            if(context instanceof MainActivity){
                                Track_List.this.notifyDataSetChanged();
                            }
                            Toast.makeText(context.getBaseContext(),favorites.getName()+" removed as a Favourite",Toast.LENGTH_LONG).show();
                        } else {
                            if(MainActivity.sizeStarred() < 20){
                                ImageButton favi = (ImageButton) finalConvertView.findViewById(R.id.favrouties);
                                favi.setImageResource(android.R.drawable.btn_star_big_on);
                                list.get(pos).setStar(true);
                                Favorites favorites = list.get(pos);
                                MainActivity.addStarred(favorites,context);
                                Toast.makeText(context.getBaseContext(),favorites.getName()+" added as a Favourite",Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(context.getBaseContext(),"maximum number of favorites list is reached",Toast.LENGTH_LONG).show();
                            }

                        }

                }
            });
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(context instanceof MainActivity){
                        mContext.callIntentTrack(list.get(pos));
                    } else if(context instanceof SearchResult){
                        sContext.callIntent(list.get(pos));
                    } else {
                        String tx = new String();
                        //tx = list.get(pos).getName().trim().replaceAll("\\(.*?\\) ?", "");
                        String art = new String();
                        //art = list.get(pos).getArtist().trim().replaceAll("\\(.*?\\) ?", "");
                        String encode = " ";
                        try {
                            tx = URLEncoder.encode(list.get(pos).getName().trim(),"UTF-8");
                            if(!(list.get(pos).getArtist().trim().isEmpty())){
                                art = URLEncoder.encode(list.get(pos).getArtist().trim(),"UTF-8");
                                encode = "&artist=" + art;

                            }
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        String u = new String("http://ws.audioscrobbler.com/2.0/?method=track.getsimilar"+encode.trim()+"&track="+tx.trim()+"&api_key=ef92cdbddee6dba109365b0a5c5d4206&format=json&limit=10");
                        track_details.getdata(u);
                        track_details.loadData(list.get(pos));
                    }

                }
            });
        }
        return convertView;
    }
}
