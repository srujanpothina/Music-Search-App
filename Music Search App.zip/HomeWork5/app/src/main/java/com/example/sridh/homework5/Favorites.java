package com.example.sridh.homework5;

import android.graphics.Bitmap;

import java.io.Serializable;

/**
 * Created by sridh on 10/9/2017.
 */

public class Favorites implements Serializable {
    String image_URL_small;
    String image_URL_large;
    String name;
    String artist;
    String url;
    Boolean star;

    public Favorites() {

    }

    public String getImage_URL_large() {
        return image_URL_large;
    }

    public void setImage_URL_large(String image_URL_large) {
        this.image_URL_large = image_URL_large;
    }

    public String getImage_URL_small() {
        return image_URL_small;
    }

    public void setImage_URL_small(String image_URL_small) {
        this.image_URL_small = image_URL_small;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Favorites(String image_URL_small, String image_URL_large, String name, String artist, String url,Boolean star) {
        this.image_URL_small = image_URL_small;
        this.image_URL_large = image_URL_large;
        this.name = name;
        this.artist = artist;
        this.url = url;
        this.star = star;
    }

    @Override
    public String toString() {
        return "Favorites{" +
                "image_URL_small='" + image_URL_small + '\'' +
                "image_URL_large='" + image_URL_large + '\'' +
                ", name='" + name + '\'' +
                ", artist='" + artist + '\'' +
                ", url='" + url + '\'' +
                '}';
    }

    public Boolean getStar() {
        return star;
    }

    public void setStar(Boolean star) {
        this.star = star;
    }
}
